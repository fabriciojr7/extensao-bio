import { AiOutlineMail, AiOutlineInstagram } from "react-icons/ai";

import {
  Line, Container, Logo, NavLink, Bars, NavMenu,
  NavBtn,
  // NavBtnLink
} from "./styles"

import logo from '../../assets/images/logo-bio.png';

export default function Header({ toggle }) {
  return (
    <>
      <Line />
      <Container>
        <Logo>
          <img src={logo} alt="Logo" />
        </Logo>
        <NavMenu>
          <NavLink to="/" >
            Home
          </NavLink>
          <NavLink to="/apresentacao" >
            Apresentação
          </NavLink>
          <NavLink to="/organizacao" >
            Organização
          </NavLink>
          <NavLink to="/programacao" >
            Programação
          </NavLink>
          <NavLink to="/resumos" >
            Resumos
          </NavLink>

          <NavLink className="btn" to="/inscricao" >
            Inscreva-se
          </NavLink>
        </NavMenu>
        <NavBtn>
          <a
            href="https://www.instagram.com/semabio.cptl/" target="_blank" rel="noopener noreferrer"
          >
            <AiOutlineInstagram />
          </a>
          <AiOutlineMail />
        </NavBtn>
        <Bars onClick={toggle} />
      </Container>
    </>
  )
}
